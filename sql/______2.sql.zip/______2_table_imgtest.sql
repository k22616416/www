
-- --------------------------------------------------------

--
-- 資料表結構 `imgtest`
--

CREATE TABLE `imgtest` (
  `img` mediumblob NOT NULL,
  `imgtype` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
