
-- --------------------------------------------------------

--
-- 資料表結構 `農產品`
--

CREATE TABLE `農產品` (
  `產品編號` int(11) NOT NULL,
  `產品號` int(11) NOT NULL,
  `名稱` varchar(255) NOT NULL,
  `限額公斤價` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 傾印資料表的資料 `農產品`
--

INSERT INTO `農產品` (`產品編號`, `產品號`, `名稱`, `限額公斤價`) VALUES
(0, 0, '產品1', 0),
(1, 1, '產品2', 0);
