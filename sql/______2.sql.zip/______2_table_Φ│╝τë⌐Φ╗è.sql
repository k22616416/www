
-- --------------------------------------------------------

--
-- 資料表結構 `購物車`
--

CREATE TABLE `購物車` (
  `使用者帳號` varchar(255) NOT NULL,
  `訂單編號` varchar(255) NOT NULL,
  `產品編號` varchar(20) NOT NULL,
  `數量` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
