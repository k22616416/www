
-- --------------------------------------------------------

--
-- 資料表結構 `配銷方式`
--

CREATE TABLE `配銷方式` (
  `付款方式` varchar(255) NOT NULL,
  `地址` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
