
-- --------------------------------------------------------

--
-- 資料表結構 `黑名單`
--

CREATE TABLE `黑名單` (
  `使用者帳號` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
