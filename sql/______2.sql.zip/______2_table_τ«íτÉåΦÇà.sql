
-- --------------------------------------------------------

--
-- 資料表結構 `管理者`
--

CREATE TABLE `管理者` (
  `使用者帳號` int(11) NOT NULL,
  `使用者密碼` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
